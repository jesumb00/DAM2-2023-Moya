package com.example.urbanfit.ui.home

interface AdapterCallbackBookingGym {
    fun onItemClicked(data: BookingGYM)
}