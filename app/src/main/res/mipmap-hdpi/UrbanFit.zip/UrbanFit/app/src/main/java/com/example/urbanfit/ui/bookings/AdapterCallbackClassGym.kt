package com.example.urbanfit.ui.bookings

import com.example.urbanfit.ClassGym

interface AdapterCallbackClassGym {
    fun onItemClicked(data: ClassGym)
}